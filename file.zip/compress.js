#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

// Load environment variables
require("dotenv").config();

// Simple progress bar implementation
class SimpleProgressBar {
  constructor(format, options = {}) {
    this.format = format;
    this.total = options.total || 100;
    this.current = 0;
    this.width = options.width || 40;
    this.complete = options.complete || "█";
    this.incomplete = options.incomplete || "░";
  }

  tick(amount = 1) {
    this.current += amount;
    this.render();
  }

  update(ratio) {
    this.current = Math.floor(this.total * ratio);
    this.render();
  }

  render() {
    const percent = Math.min(100, (this.current / this.total) * 100);
    const filled = Math.floor((this.current / this.total) * this.width);
    const empty = this.width - filled;

    const bar = this.complete.repeat(filled) + this.incomplete.repeat(empty);
    const formatted = this.format
      .replace(":bar", bar)
      .replace(":current", this.current)
      .replace(":total", this.total)
      .replace(":percent", `${percent.toFixed(1)}%`)
      .replace(":etas", this.calculateETA());

    process.stdout.write(`\r${formatted}`);
  }

  calculateETA() {
    // Simple ETA calculation
    return "--:--";
  }

  finish() {
    this.current = this.total;
    this.render();
    process.stdout.write("\n");
  }
}

// Configuration class
class GitCompressorConfig {
  constructor() {
    this.sourceDir = process.env.SOURCE_DIR || "./source";
    this.outputDir = process.env.OUTPUT_DIR || "./destination";
    this.startDate = process.env.START_DATE || "2025-06-18T09:00:00";
    this.endDate = process.env.END_DATE || null;
    this.compressionRatio = process.env.COMPRESSION_RATIO
      ? parseFloat(process.env.COMPRESSION_RATIO)
      : null;
    this.originalDays = process.env.ORIGINAL_DAYS
      ? parseFloat(process.env.ORIGINAL_DAYS)
      : null;
    this.targetDays = process.env.TARGET_DAYS
      ? parseFloat(process.env.TARGET_DAYS)
      : null;
    this.backupOriginal = process.env.BACKUP_ORIGINAL === "true";
    this.verbose = process.env.VERBOSE === "true";
    this.dryRun = process.env.DRY_RUN === "true";
    this.force = process.env.FORCE === "true";
  }

  validate() {
    const errors = [];

    if (!fs.existsSync(this.sourceDir)) {
      errors.push(`Source directory '${this.sourceDir}' does not exist.`);
    }

    if (
      this.compressionRatio &&
      (this.compressionRatio <= 0 || this.compressionRatio > 1)
    ) {
      errors.push("Compression ratio must be between 0 and 1.");
    }

    if (this.originalDays && this.originalDays <= 0) {
      errors.push("Original days must be positive.");
    }

    if (this.targetDays && this.targetDays <= 0) {
      errors.push("Target days must be positive.");
    }

    if (this.startDate && !this.isValidDate(this.startDate)) {
      errors.push("Start date must be a valid ISO date string.");
    }

    if (this.endDate && !this.isValidDate(this.endDate)) {
      errors.push("End date must be a valid ISO date string.");
    }

    return errors;
  }

  isValidDate(dateString) {
    const date = new Date(dateString);
    return date instanceof Date && !isNaN(date);
  }

  calculateCompressionRatio() {
    if (this.compressionRatio) return this.compressionRatio;
    if (this.originalDays && this.targetDays)
      return this.targetDays / this.originalDays;
    return null;
  }
}

// Git History Compressor class
class GitHistoryCompressor {
  constructor(config) {
    this.config = config;
    this.stats = {
      totalCommits: 0,
      processedCommits: 0,
      errors: 0,
      startTime: null,
      endTime: null,
    };
  }

  log(message, level = "info") {
    const timestamp = new Date().toISOString();
    const prefix = `[${timestamp}] [${level.toUpperCase()}]`;

    if (level === "error") {
      console.error(`\n${prefix} ${message}`);
    } else if (level === "warn") {
      console.warn(`\n${prefix} ${message}`);
    } else if (this.config.verbose || level === "info") {
      console.log(`\n${prefix} ${message}`);
    }
  }

  async run() {
    try {
      this.stats.startTime = new Date();
      this.log("🚀 Starting Git Timeline Compression Engine", "info");
      this.log(
        `Configuration: ${JSON.stringify(this.config, null, 2)}`,
        "debug"
      );

      // Validate configuration
      const errors = this.config.validate();
      if (errors.length > 0) {
        throw new Error(`Configuration errors:\n${errors.join("\n")}`);
      }

      // Copy source files (this will handle destination directory checks)
      await this.copySourceFiles();

      // Create backup if requested (after files are copied)
      if (this.config.backupOriginal) {
        await this.createBackup();
      }

      // Copy git repository
      await this.copyGitRepository();

      // Analyze git history
      const commits = await this.analyzeGitHistory();

      if (commits.length === 0) {
        this.log("No commits found. Nothing to compress.", "warn");
        return;
      }

      // Calculate new timeline using actual commit history and user-specified start/end dates
      this.log(
        `DEBUG: Using startDate=${this.config.startDate}, endDate=${this.config.endDate}`,
        "debug"
      );
      const timeline = this.calculateNewTimeline(
        commits,
        this.config.startDate,
        this.config.endDate
      );
      this.lastTimeline = timeline;

      // Generate date_map.json for filter-repo
      await this.generateDateMap(commits, timeline);

      // Write rewrite_dates.py to output directory
      const pythonScript = `import json\n\nwith open(\"date_map.json\", \"r\") as f:\n    date_map = json.load(f)\n\ndef commit_callback(commit, metadata):\n    new_date = date_map.get(commit.original_id.decode())\n    if new_date:\n        commit.author_date = new_date.encode()\n        commit.committer_date = new_date.encode()\n`;
      const pyPath = path.join(this.config.outputDir, "rewrite_dates.py");
      fs.writeFileSync(pyPath, pythonScript, "utf-8");
      this.log("Wrote rewrite_dates.py for git filter-repo.", "info");

      // Run git filter-repo
      try {
        this.log("Running git filter-repo to rewrite commit dates...", "info");
        execSync(
          `git filter-repo --force --replace-refs delete-no-add --commit-callback rewrite_dates.py`,
          { cwd: this.config.outputDir, stdio: "inherit" }
        );
        this.log("✅ git filter-repo completed successfully.", "info");
      } catch (err) {
        this.log(`❌ git filter-repo failed: ${err.message}`, "error");
      }

      this.log(
        "All steps complete. Your git history is now compressed and rewritten!",
        "info"
      );
      this.stats.endTime = new Date();
      this.printSummary();
      return;

      // Apply date compression (will be replaced by filter-repo)
      // await this.applyDateCompression(commits, timeline);
    } catch (error) {
      this.log(`Fatal error: ${error.message}`, "error");
      if (this.config.verbose) {
        console.error(error.stack);
      }
      process.exit(1);
    }
  }

  async createBackup() {
    const backupDir = `${this.config.outputDir}_backup_${Date.now()}`;
    this.log(`Creating backup at: ${backupDir}`, "info");

    if (fs.existsSync(this.config.outputDir)) {
      // Count files for backup progress
      const totalFiles = this.countFiles(this.config.outputDir);
      const progressBar = new SimpleProgressBar(
        "💾 Creating backup snapshot [:bar] :current/:total :percent",
        {
          complete: "█",
          incomplete: "░",
          width: 40,
          total: totalFiles,
        }
      );

      await this.copyDirectory(this.config.outputDir, backupDir, progressBar);
      progressBar.finish();
      this.log("✅ Backup created successfully", "info");
    } else {
      this.log("⚠️  No destination directory to backup (first run)", "warn");
    }
  }

  async copySourceFiles() {
    this.log("📁 Initializing file transfer...", "info");

    if (fs.existsSync(this.config.outputDir) && !this.config.force) {
      throw new Error(
        `Output directory '${this.config.outputDir}' already exists. Use --force or set FORCE=true to overwrite.`
      );
    }

    if (fs.existsSync(this.config.outputDir)) {
      fs.rmSync(this.config.outputDir, { recursive: true, force: true });
    }

    // Count total files for progress bar
    const totalFiles = this.countFiles(this.config.sourceDir);
    const progressBar = new SimpleProgressBar(
      "📁 Copying source files [:bar] :current/:total :percent",
      {
        complete: "█",
        incomplete: "░",
        width: 40,
        total: totalFiles,
      }
    );

    await this.copyDirectory(
      this.config.sourceDir,
      this.config.outputDir,
      progressBar
    );
    progressBar.finish();
    this.log("✅ Source files copied successfully", "info");
  }

  countFiles(dir) {
    let count = 0;
    const entries = fs.readdirSync(dir, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (entry.name === ".git") continue;
        count += this.countFiles(fullPath);
      } else {
        count++;
      }
    }
    return count;
  }

  async copyDirectory(src, dest, progressBar = null) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }

    const entries = fs.readdirSync(src, { withFileTypes: true });

    for (const entry of entries) {
      const srcPath = path.join(src, entry.name);
      const destPath = path.join(dest, entry.name);

      if (entry.isDirectory()) {
        if (entry.name === ".git") {
          this.log("Skipping .git directory during file copy...", "debug");
          continue;
        }
        await this.copyDirectory(srcPath, destPath, progressBar);
      } else {
        fs.copyFileSync(srcPath, destPath);
        if (progressBar) {
          progressBar.tick();
        }
      }
    }
  }

  async copyGitRepository() {
    this.log("🔧 Initializing git repository transfer...", "info");

    const destGitPath = path.join(this.config.outputDir, ".git");
    const srcGitPath = path.join(this.config.sourceDir, ".git");

    if (!fs.existsSync(srcGitPath)) {
      throw new Error(
        "No .git directory found in source. Cannot compress git history."
      );
    }

    if (fs.existsSync(destGitPath)) {
      fs.rmSync(destGitPath, { recursive: true, force: true });
    }

    // Use progress bar for .git copy
    const totalFiles = this.countFiles(srcGitPath);
    const progressBar = new SimpleProgressBar(
      "🔧 Copying git repository [:bar] :current/:total :percent",
      {
        complete: "█",
        incomplete: "░",
        width: 40,
        total: totalFiles,
      }
    );

    await this.copyDirectory(srcGitPath, destGitPath, progressBar);
    progressBar.finish();
    this.log("✅ Git repository copied successfully (Node.js method)", "info");
  }

  async analyzeGitHistory() {
    this.log("📊 Analyzing git history...", "info");

    const originalCwd = process.cwd();
    process.chdir(this.config.outputDir);

    try {
      const output = execSync(
        'git log --reverse --format="%H %at %an %ae %s"',
        { encoding: "utf8" }
      );

      const commits = output
        .trim()
        .split("\n")
        .filter((line) => line.trim())
        .map((line) => {
          const [hash, timestamp, author, email, ...messageParts] =
            line.split(" ");
          const message = messageParts.join(" ");
          return {
            hash,
            timestamp: parseInt(timestamp),
            author,
            email,
            message,
            date: new Date(parseInt(timestamp) * 1000),
          };
        });

      this.stats.totalCommits = commits.length;
      this.log(`Found ${commits.length} commits to process`, "info");

      if (commits.length > 0) {
        const firstCommit = commits[0];
        const lastCommit = commits[commits.length - 1];
        this.log(
          `Original timeline: ${firstCommit.date.toISOString()} to ${lastCommit.date.toISOString()}`,
          "info"
        );
      }

      return commits;
    } finally {
      process.chdir(originalCwd);
    }
  }

  async generateDateMap(commits, timeline) {
    const dateMap = {};
    for (let i = 0; i < commits.length; i++) {
      const commit = commits[i];
      const originalOffset = commit.timestamp - timeline.originalStart;
      const newOffset =
        (originalOffset / timeline.originalDuration) * timeline.targetDuration;
      const newTimestamp = Math.floor(timeline.startTimestamp + newOffset);
      const newDate = new Date(newTimestamp * 1000).toISOString();
      dateMap[commit.hash] = newDate;
    }
    fs.writeFileSync(
      path.join(this.config.outputDir, "date_map.json"),
      JSON.stringify(dateMap, null, 2),
      "utf-8"
    );
    this.log(`Generated date_map.json with ${commits.length} entries.`, "info");
  }

  calculateNewTimeline(commits, startDate, endDate) {
    const originalStart = commits[0].timestamp;
    const originalEnd = commits[commits.length - 1].timestamp;
    const originalDuration = originalEnd - originalStart;

    const startTimestamp = new Date(startDate).getTime() / 1000;
    const endTimestamp = endDate
      ? new Date(endDate).getTime() / 1000
      : startTimestamp + originalDuration;

    const targetDuration = endTimestamp - startTimestamp;

    return {
      originalStart,
      originalEnd,
      originalDuration,
      targetDuration,
      startTimestamp,
      endTimestamp,
      compressionRatio: targetDuration / originalDuration,
    };
  }

  async applyDateCompression(commits, timeline) {
    this.log("⏰ Initializing timeline compression...", "info");

    const originalCwd = process.cwd();
    process.chdir(this.config.outputDir);

    // Clean the working directory before rewriting history
    try {
      execSync("git reset --hard && git clean -fd", { stdio: "pipe" });
    } catch (cleanError) {
      this.log(
        `Warning: Could not clean working directory: ${cleanError.message}`,
        "warn"
      );
    }

    // Create progress bar for commit processing
    const progressBar = new SimpleProgressBar(
      "⏰ Adjusting commit dates [:bar] :current/:total :percent",
      {
        complete: "█",
        incomplete: "░",
        width: 40,
        total: commits.length,
      }
    );

    try {
      for (let i = 0; i < commits.length; i++) {
        const commit = commits[i];
        const originalOffset = commit.timestamp - timeline.originalStart;
        const newOffset =
          (originalOffset / timeline.originalDuration) *
          timeline.targetDuration;
        const newTimestamp = Math.floor(timeline.startTimestamp + newOffset);
        const newDate = new Date(newTimestamp * 1000).toISOString();

        this.log(
          `Processing commit ${i + 1}/${
            commits.length
          }: ${commit.hash.substring(0, 8)} -> ${newDate}`,
          "debug"
        );

        try {
          let envFilterCmd;
          if (process.platform === "win32") {
            envFilterCmd = `git filter-branch -f --env-filter \"if [ $GIT_COMMIT = ${commit.hash} ]; then export GIT_AUTHOR_DATE=${newDate}; export GIT_COMMITTER_DATE=${newDate}; fi\"`;
          } else {
            envFilterCmd = `git filter-branch -f --env-filter 'if [ $GIT_COMMIT = \"${commit.hash}\" ]; then export GIT_AUTHOR_DATE=\"${newDate}\"; export GIT_COMMITTER_DATE=\"${newDate}\"; fi'`;
          }
          execSync(envFilterCmd, { stdio: "pipe" });

          this.stats.processedCommits++;
        } catch (error) {
          this.log(
            `Warning: Could not adjust commit ${commit.hash.substring(0, 8)}: ${
              error.message
            }`,
            "warn"
          );
          this.stats.errors++;
        }

        progressBar.tick();
      }

      progressBar.finish();
      this.log("✅ Date compression completed", "info");
    } finally {
      process.chdir(originalCwd);
    }
  }

  printSummary() {
    const duration = this.stats.endTime - this.stats.startTime;

    console.log("\n" + "=".repeat(60));
    console.log("🎉 GIT TIMELINE COMPRESSION ENGINE - COMPLETED");
    console.log("=".repeat(60));
    console.log(`📊 Statistics:`);
    console.log(`   • Total commits: ${this.stats.totalCommits}`);
    console.log(`   • Processed commits: ${this.stats.processedCommits}`);
    console.log(`   • Errors: ${this.stats.errors}`);
    console.log(`   • Duration: ${(duration / 1000).toFixed(2)} seconds`);
    if (this.lastTimeline) {
      console.log(
        `   • Compression ratio: ${this.lastTimeline.compressionRatio.toFixed(
          3
        )}`
      );
    }
    console.log(`\n📁 Output location: ${path.resolve(this.config.outputDir)}`);
  }
}

// Add the rest of the main execution and exports if needed
function parseArguments() {
  // You can expand this to actually parse CLI args if needed
  return new GitCompressorConfig();
}

if (require.main === module) {
  const config = parseArguments();
  const compressor = new GitHistoryCompressor(config);
  compressor.run();
}
